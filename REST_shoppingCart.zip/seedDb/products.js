exports.mockProductData = [
  {
    name: "Virknål",
    price: 60,
  },
  {
    name: "Stickor",
    price: 149,
  },
  {
    name: "Mönster",
    price: 45,
  },
  {
    name: "Garn",
    price: 89,
  },
  {
    name: "Maskmarkörer",
    price: 50,
  },
  {
    name: "Sax",
    price: 150,
  },
];
